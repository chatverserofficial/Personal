import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Plus, Copy, Check, RefreshCw, Pencil, Trash2, Loader2, Power, AlertTriangle } from 'lucide-react';
import type { InstanceView, MintedInstance } from '../services/api';
import {
  usePluginInstancesQuery,
  useCreateInstanceMutation,
  useRegenerateInstanceSecretMutation,
  useUpdateInstanceMutation,
  useDeleteInstanceMutation,
} from '../hooks/queries';
import { isValidInstanceId, isValidInstanceSecret, parseInstanceConfig } from '../utils/instanceForm';
import { copyToClipboard } from '../utils/clipboard';
import { Modal } from './Modal';
import { useToast } from '../hooks/useToast';
import './PluginInstances.css';

const emptyForm = { instanceId: '', sessionScope: '', verifyToken: '', secret: '', config: '' };

export function PluginInstances({ pluginId }: { pluginId: string }) {
  const { t } = useTranslation();
  const toast = useToast();
  const { data: instances = [], isLoading, isError } = usePluginInstancesQuery(pluginId, true);
  const createM = useCreateInstanceMutation(pluginId);
  const regenM = useRegenerateInstanceSecretMutation(pluginId);
  const updateM = useUpdateInstanceMutation(pluginId);
  const deleteM = useDeleteInstanceMutation(pluginId);

  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm);
  const [formError, setFormError] = useState<string | null>(null);
  const [minted, setMinted] = useState<MintedInstance | null>(null); // secret-shown-once view
  const [mintedKind, setMintedKind] = useState<'created' | 'regenerated'>('created');
  const [editing, setEditing] = useState<InstanceView | null>(null);
  const [editForm, setEditForm] = useState({ sessionScope: '', config: '' });
  const [editError, setEditError] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<{ type: 'delete' | 'regenerate'; inst: InstanceView } | null>(null);
  const [copied, setCopied] = useState<string | null>(null);

  const copy = async (text: string, id: string) => {
    if (await copyToClipboard(text)) {
      setCopied(id);
      setTimeout(() => setCopied(null), 2000);
    }
  };

  const openCreate = () => {
    setForm(emptyForm);
    setFormError(null);
    setShowForm(true);
  };

  const submitCreate = async () => {
    if (!isValidInstanceId(form.instanceId)) {
      setFormError(t('plugins.instances.errors.invalidId'));
      return;
    }
    const parsed = parseInstanceConfig(form.config);
    if (!parsed.ok) {
      setFormError(t('plugins.instances.errors.invalidJson'));
      return;
    }
    if (!isValidInstanceSecret(form.secret)) {
      setFormError(t('plugins.instances.errors.invalidSecret'));
      return;
    }
    try {
      const created = await createM.mutateAsync({
        instanceId: form.instanceId,
        sessionScope: form.sessionScope.trim() || undefined,
        verifyToken: form.verifyToken.trim() || undefined,
        secret: form.secret.trim() || undefined,
        config: parsed.value,
      });
      setShowForm(false);
      setForm(emptyForm);
      setMintedKind('created');
      setMinted(created);
      toast.success(t('plugins.instances.toasts.created'), created.instanceId);
    } catch (err) {
      const e = err as Error & { status?: number };
      setFormError(e.status === 409 ? t('plugins.instances.errors.duplicateId') : e.message);
    }
  };

  const toggleEnabled = async (inst: InstanceView) => {
    try {
      await updateM.mutateAsync({ instanceId: inst.instanceId, body: { enabled: !inst.enabled } });
      toast.success(t('plugins.instances.toasts.updated'), inst.instanceId);
    } catch (err) {
      toast.error(t('plugins.instances.toasts.actionFailed'), (err as Error).message);
    }
  };

  const openEdit = (inst: InstanceView) => {
    setEditing(inst);
    setEditForm({
      sessionScope: inst.sessionScope ?? '',
      config: inst.config ? JSON.stringify(inst.config, null, 2) : '',
    });
    setEditError(null);
  };

  const submitEdit = async () => {
    if (!editing) return;
    const parsed = parseInstanceConfig(editForm.config);
    if (!parsed.ok) {
      setEditError(t('plugins.instances.errors.invalidJson'));
      return;
    }
    try {
      await updateM.mutateAsync({
        instanceId: editing.instanceId,
        // Blank → omit (leave scope unchanged); mirrors create. Sending '' would corrupt an
        // all-sessions (null) instance into a literal empty scope the backend never clears.
        body: { sessionScope: editForm.sessionScope.trim() || undefined, config: parsed.value ?? {} },
      });
      setEditing(null);
      toast.success(t('plugins.instances.toasts.updated'), editing.instanceId);
    } catch (err) {
      setEditError((err as Error).message);
    }
  };

  const runConfirm = async () => {
    if (!confirm) return;
    const { type, inst } = confirm;
    setConfirm(null);
    try {
      if (type === 'delete') {
        await deleteM.mutateAsync(inst.instanceId);
        toast.success(t('plugins.instances.toasts.deleted'), inst.instanceId);
      } else {
        const res = await regenM.mutateAsync(inst.instanceId);
        setMintedKind('regenerated');
        setMinted(res);
        toast.success(t('plugins.instances.toasts.secretRegenerated'), inst.instanceId);
      }
    } catch (err) {
      toast.error(t('plugins.instances.toasts.actionFailed'), (err as Error).message);
    }
  };

  return (
    <div className="plugin-instances">
      <div className="pi-header">
        <p className="pi-desc">{t('plugins.instances.description')}</p>
        <button className="btn-primary" onClick={openCreate}>
          <Plus size={16} />
          {t('plugins.instances.create')}
        </button>
      </div>

      {isLoading ? (
        <div className="pi-loading">
          <Loader2 className="animate-spin" size={24} />
        </div>
      ) : isError ? (
        <p className="pi-error">{t('plugins.instances.loadError')}</p>
      ) : instances.length === 0 ? (
        <p className="pi-empty">{t('plugins.instances.empty')}</p>
      ) : (
        <div className="pi-list">
          {instances.map(inst => (
            <div key={inst.id} className="pi-row">
              <div className="pi-main">
                <span className="pi-id">{inst.instanceId}</span>
                <span className="pi-scope">{inst.sessionScope || t('plugins.instances.allSessions')}</span>
              </div>
              {inst.ingressUrls[0] && (
                <div className="pi-url">
                  <code title={inst.ingressUrls[0].url}>{inst.ingressUrls[0].url}</code>
                  <button
                    className="icon-btn-sm"
                    onClick={() => void copy(inst.ingressUrls[0].url, `url-${inst.id}`)}
                    title={t('plugins.instances.actions.copy')}
                  >
                    {copied === `url-${inst.id}` ? <Check size={14} /> : <Copy size={14} />}
                  </button>
                </div>
              )}
              <span className={`pi-badge ${inst.enabled ? 'on' : 'off'}`}>
                {inst.enabled ? t('plugins.instances.enabled') : t('plugins.instances.disabled')}
              </span>
              <div className="pi-actions">
                <button
                  className="icon-btn"
                  onClick={() => void toggleEnabled(inst)}
                  title={t(`plugins.instances.actions.${inst.enabled ? 'disable' : 'enable'}`)}
                >
                  <Power size={16} />
                </button>
                <button
                  className="icon-btn"
                  onClick={() => setConfirm({ type: 'regenerate', inst })}
                  title={t('plugins.instances.actions.regenerate')}
                >
                  <RefreshCw size={16} />
                </button>
                <button className="icon-btn" onClick={() => openEdit(inst)} title={t('plugins.instances.actions.edit')}>
                  <Pencil size={16} />
                </button>
                <button
                  className="icon-btn danger"
                  onClick={() => setConfirm({ type: 'delete', inst })}
                  title={t('plugins.instances.actions.delete')}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create modal — form, or the secret-shown-once view after mint */}
      {showForm && (
        <Modal
          open
          onClose={() => setShowForm(false)}
          title={t('plugins.instances.create')}
          closeLabel={t('common.close')}
          footer={
            <>
              <button className="btn-secondary" onClick={() => setShowForm(false)}>
                {t('common.cancel')}
              </button>
              <button
                className="btn-primary"
                onClick={() => void submitCreate()}
                disabled={createM.isPending || !form.instanceId}
              >
                {createM.isPending ? <Loader2 className="animate-spin" size={16} /> : t('common.create')}
              </button>
            </>
          }
        >
          <label htmlFor="pi-1">{t('plugins.instances.form.instanceId')}</label>
          <input
            id="pi-1"
            type="text"
            value={form.instanceId}
            placeholder={t('plugins.instances.form.instanceIdPlaceholder')}
            onChange={e => setForm({ ...form, instanceId: e.target.value })}
          />
          <p className="pi-hint">{t('plugins.instances.form.instanceIdHint')}</p>
          <label htmlFor="pi-2">{t('plugins.instances.form.sessionScope')}</label>
          <input
            id="pi-2"
            type="text"
            value={form.sessionScope}
            placeholder={t('plugins.instances.form.sessionScopePlaceholder')}
            onChange={e => setForm({ ...form, sessionScope: e.target.value })}
          />
          <label htmlFor="pi-3">{t('plugins.instances.form.verifyToken')}</label>
          <input
            id="pi-3"
            type="text"
            value={form.verifyToken}
            placeholder={t('plugins.instances.form.verifyTokenPlaceholder')}
            onChange={e => setForm({ ...form, verifyToken: e.target.value })}
          />
          <label htmlFor="pi-4">{t('plugins.instances.form.secret')}</label>
          <input
            id="pi-4"
            type="text"
            value={form.secret}
            placeholder={t('plugins.instances.form.secretPlaceholder')}
            onChange={e => setForm({ ...form, secret: e.target.value })}
          />
          <p className="pi-hint">{t('plugins.instances.form.secretHint')}</p>
          <label htmlFor="pi-5">{t('plugins.instances.form.config')}</label>
          <textarea
            id="pi-5"
            value={form.config}
            placeholder={t('plugins.instances.form.configPlaceholder')}
            onChange={e => setForm({ ...form, config: e.target.value })}
          />
          {formError && <p className="pi-error">{formError}</p>}
        </Modal>
      )}

      {/* Secret-shown-once modal (after create or regenerate) */}
      {minted && (
        <Modal
          open
          onClose={() => setMinted(null)}
          title={
            mintedKind === 'regenerated'
              ? t('plugins.instances.regenerate.title')
              : t('plugins.instances.created.title')
          }
          closeLabel={t('common.close')}
          footer={
            <button className="btn-secondary" onClick={() => setMinted(null)}>
              {t('common.close')}
            </button>
          }
        >
          <p className="pi-hint">{t('plugins.instances.created.hint')}</p>
          <label>{t('plugins.instances.created.secret')}</label>
          <div className="pi-secret">
            <code>{minted.secret}</code>
            <button className="btn-primary" onClick={() => void copy(minted.secret, 'secret')}>
              {copied === 'secret' ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
          <label>{t('plugins.instances.created.ingressUrls')}</label>
          {minted.ingressUrls.map(u => (
            <div key={u.route} className="pi-secret">
              <code>{u.url}</code>
              <button className="btn-primary" onClick={() => void copy(u.url, `mint-${u.route}`)}>
                {copied === `mint-${u.route}` ? <Check size={16} /> : <Copy size={16} />}
              </button>
            </div>
          ))}
        </Modal>
      )}

      {/* Edit modal — sessionScope + config */}
      {editing && (
        <Modal
          open
          onClose={() => setEditing(null)}
          title={t('plugins.instances.edit.title', { id: editing.instanceId })}
          closeLabel={t('common.close')}
          footer={
            <>
              <button className="btn-secondary" onClick={() => setEditing(null)}>
                {t('common.cancel')}
              </button>
              <button className="btn-primary" onClick={() => void submitEdit()} disabled={updateM.isPending}>
                {updateM.isPending ? (
                  <Loader2 className="animate-spin" size={16} />
                ) : (
                  t('plugins.instances.actions.save')
                )}
              </button>
            </>
          }
        >
          <label htmlFor="pi-6">{t('plugins.instances.form.sessionScope')}</label>
          <input
            id="pi-6"
            type="text"
            value={editForm.sessionScope}
            placeholder={t('plugins.instances.form.sessionScopePlaceholder')}
            onChange={e => setEditForm({ ...editForm, sessionScope: e.target.value })}
          />
          <label htmlFor="pi-7">{t('plugins.instances.form.config')}</label>
          <textarea
            id="pi-7"
            value={editForm.config}
            placeholder={t('plugins.instances.form.configPlaceholder')}
            onChange={e => setEditForm({ ...editForm, config: e.target.value })}
          />
          {editError && <p className="pi-error">{editError}</p>}
        </Modal>
      )}

      {/* Confirm modal — delete or regenerate */}
      {confirm && (
        <Modal
          open
          onClose={() => setConfirm(null)}
          title={t(`plugins.instances.${confirm.type}.title`)}
          className="confirm-modal"
          closeLabel={t('common.close')}
          footer={
            <>
              <button className="btn-secondary" onClick={() => setConfirm(null)}>
                {t('common.cancel')}
              </button>
              <button
                className={confirm.type === 'delete' ? 'btn-danger' : 'btn-primary'}
                onClick={() => void runConfirm()}
              >
                {t(`plugins.instances.${confirm.type}.action`)}
              </button>
            </>
          }
        >
          <div className="pi-confirm-icon">
            <AlertTriangle size={40} />
          </div>
          <p>{t(`plugins.instances.${confirm.type}.confirm`, { id: confirm.inst.instanceId })}</p>
        </Modal>
      )}
    </div>
  );
}
