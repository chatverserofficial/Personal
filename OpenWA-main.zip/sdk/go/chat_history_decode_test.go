package openwa

import (
	"encoding/json"
	"testing"
)

// The chat-history route returns the engine payload verbatim, so the only thing standing between a
// caller and a silently-empty field is this struct's tags. Nothing else exercises them: the routing
// test asserts the URL and never decodes a body.
func TestChatHistoryMessageDecodesEngineFields(t *testing.T) {
	raw := []byte(`{
	  "id":"true_628@c.us_ABC","from":"628@c.us","to":"629@c.us","chatId":"628@c.us",
	  "body":"","type":"call","timestamp":1719312000,"fromMe":false,"isGroup":false,
	  "kind":"individual","ephemeralDuration":604800,
	  "call":{"video":true,"missed":false},
	  "contact":{"pushName":"Budi","number":"628","isMyContact":true,"verifiedLevel":0,"labels":["vip"]}
	}`)

	var m ChatHistoryMessage
	if err := json.Unmarshal(raw, &m); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if m.EphemeralDuration != 604800 {
		t.Errorf("ephemeralDuration = %d, want 604800", m.EphemeralDuration)
	}
	if m.Call == nil || !m.Call.Video || m.Call.Missed {
		t.Errorf("call = %+v, want {Video:true Missed:false}", m.Call)
	}
	if m.Contact == nil || m.Contact.PushName != "Budi" || m.Contact.Number != "628" || !m.Contact.IsMyContact {
		t.Errorf("contact = %+v", m.Contact)
	}
	if len(m.Contact.Labels) != 1 || m.Contact.Labels[0] != "vip" {
		t.Errorf("contact.labels = %v, want [vip]", m.Contact.Labels)
	}
	// The pointer is the point: verifiedLevel 0 is "unverified", not "the server said nothing".
	if m.Contact.VerifiedLevel == nil || *m.Contact.VerifiedLevel != 0 {
		t.Errorf("contact.verifiedLevel = %v, want a pointer to 0", m.Contact.VerifiedLevel)
	}
}

func TestChatHistoryMessageLeavesAbsentFieldsEmpty(t *testing.T) {
	raw := []byte(`{"id":"x","from":"a","to":"b","chatId":"c","body":"","type":"text",
	  "timestamp":1,"fromMe":false,"isGroup":false,"kind":"individual"}`)

	var m ChatHistoryMessage
	if err := json.Unmarshal(raw, &m); err != nil {
		t.Fatalf("unmarshal: %v", err)
	}
	if m.Call != nil || m.Contact != nil || m.Font != nil {
		t.Errorf("absent optionals should stay nil: call=%v contact=%v font=%v", m.Call, m.Contact, m.Font)
	}
	if m.EphemeralDuration != 0 || m.BackgroundColor != "" {
		t.Errorf("absent scalars should stay zero: ephemeral=%d bg=%q", m.EphemeralDuration, m.BackgroundColor)
	}
}
